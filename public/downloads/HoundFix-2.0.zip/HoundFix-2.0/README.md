# HoundFix 2.0

IT toolkit from **Two Hounds Run**. Formerly QuickFix.

Practical Windows repairs you can run from a desktop app or paste into PowerShell.

## Run (users)

1. Unzip `HoundFix-2.0`.
2. Install Python 3.10+ if needed (`python.org`) and tick **Add Python to PATH**.
3. Double-click `main.py`, or from a terminal:

```
python main.py
```

4. For network reset, printers, DISM, restore points: right-click → **Run as administrator**.

Logs live in `Documents\HoundFix\logs\`.

## Build a portable EXE (optional)

```
pip install pyinstaller
build.bat
```

`dist\HoundFix.exe` is the portable build. Windows Defender often flags unsigned PyInstaller binaries — sign before a public store listing.

## What is in the box

| Folder | Contents |
| --- | --- |
| `main.py` | Desktop app |
| `tools.json` | Catalog |
| `scripts/windows` | One `.ps1` per repair |
| `assets/logo.png` | Two Hounds mark |

## Safety

Scripts change system state. Create a restore point first (included). Two Hounds Run is not liable for data loss. MIT licensed.

Version 2.0.0 · Windows 10/11 · Two Hounds Run
