@echo off
pyinstaller --noconfirm --onefile --windowed --name HoundFix --add-data "scripts;scripts" --add-data "tools.json;." --add-data "assets;assets" main.py
echo Built dist\HoundFix.exe
