"""HoundFix 2.0 — Two Hounds Run IT toolkit."""
from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk

__version__ = "2.0.0"
IS_WINDOWS = os.name == "nt"
ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
NAVY = "#071428"
SURFACE = "#0c1d38"
ELEVATED = "#122544"
FG = "#f4f7fb"
MUTED = "#93a4bb"
BLUE = "#2f6fed"
ICE = "#5eb0ff"


def load_tools():
    path = ROOT / "tools.json"
    if not path.exists():
        path = Path(__file__).resolve().parent / "tools.json"
    return json.loads(path.read_text(encoding="utf-8"))


class HoundFix:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"HoundFix {__version__} — Two Hounds Run")
        self.root.geometry("920x720")
        self.root.configure(bg=NAVY)
        self.docs = Path.home() / "Documents" / "HoundFix"
        self.logs = self.docs / "logs"
        self.logs.mkdir(parents=True, exist_ok=True)
        self.is_admin = self._admin()
        self.tools = load_tools()
        self._header()
        self._tabs()
        self._log_panel()
        self.log("HoundFix started")
        if IS_WINDOWS and not self.is_admin:
            self.log("Standard user — elevate for full kit", "WARN")
        if not IS_WINDOWS:
            self.log("Not Windows — copy scripts from the HoundFix site instead", "WARN")

    def _admin(self) -> bool:
        if not IS_WINDOWS:
            return False
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False

    def log(self, message: str, level: str = "INFO"):
        line = f"[{datetime.now():%H:%M:%S}] {level}: {message}\n"
        try:
            self.log_text.insert("end", line)
            self.log_text.see("end")
        except Exception:
            pass
        with open(self.logs / f"houndfix_{datetime.now():%Y%m%d}.log", "a", encoding="utf-8") as fh:
            fh.write(line)

    def _header(self):
        bar = tk.Frame(self.root, bg=NAVY, height=88)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        tk.Label(bar, text="HOUNDFIX", font=("Segoe UI", 22, "bold"), bg=NAVY, fg=FG).pack(
            side="left", padx=20, pady=16
        )
        tk.Label(
            bar, text="TWO HOUNDS RUN", font=("Segoe UI", 10, "bold"), bg=NAVY, fg=BLUE
        ).pack(side="left")
        status = "Admin" if self.is_admin else ("Standard" if IS_WINDOWS else "Not Windows")
        color = "#3dd68c" if self.is_admin else "#e7b549"
        tk.Label(bar, text=status, bg=color, fg=NAVY, font=("Segoe UI", 9, "bold"), padx=10, pady=4).pack(
            side="right", padx=20
        )

    def _tabs(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TNotebook", background=SURFACE, borderwidth=0)
        style.configure("TNotebook.Tab", background=ELEVATED, foreground=FG, padding=(14, 8))
        style.map("TNotebook.Tab", background=[("selected", BLUE)])
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=12, pady=8)
        groups = {}
        for tool in self.tools:
            groups.setdefault(tool["category"], []).append(tool)
        labels = {
            "network": "Network",
            "print": "Print",
            "cleanup": "Cleanup",
            "repair": "Repair",
            "diagnose": "Diagnose",
            "power": "Power",
        }
        for key, title in labels.items():
            frame = tk.Frame(nb, bg=SURFACE)
            nb.add(frame, text=title)
            for i, tool in enumerate(groups.get(key, [])):
                self._card(frame, tool, i)

    def _card(self, parent, tool, index):
        row, col = divmod(index, 2)
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_columnconfigure(1, weight=1)
        card = tk.Frame(parent, bg=ELEVATED, padx=12, pady=12)
        card.grid(row=row, column=col, sticky="nsew", padx=8, pady=8)
        name = tool["name"] + ("  · admin" if tool.get("admin") else "")
        tk.Label(card, text=name, bg=ELEVATED, fg=FG, font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x")
        tk.Label(
            card, text=tool["summary"], bg=ELEVATED, fg=MUTED, wraplength=340, justify="left", anchor="w"
        ).pack(fill="x", pady=(4, 8))
        tk.Button(
            card,
            text="Run",
            bg=BLUE,
            fg=FG,
            relief="flat",
            padx=16,
            pady=6,
            command=lambda t=tool: threading.Thread(target=self.run_tool, args=(t,), daemon=True).start(),
        ).pack(anchor="w")

    def _log_panel(self):
        wrap = tk.Frame(self.root, bg=NAVY)
        wrap.pack(fill="both", padx=12, pady=(0, 12))
        tk.Label(wrap, text="Activity", bg=NAVY, fg=FG, anchor="w").pack(fill="x")
        self.log_text = scrolledtext.ScrolledText(
            wrap, height=8, bg="#050b16", fg=ICE, insertbackground=FG, font=("Consolas", 9)
        )
        self.log_text.pack(fill="both")

    def run_tool(self, tool):
        if not IS_WINDOWS:
            self.root.after(0, lambda: messagebox.showinfo("HoundFix", "Windows only. Copy the script from the site."))
            return
        script_path = ROOT / "scripts" / "windows" / tool["file"]
        if not script_path.exists():
            script_path = Path(__file__).resolve().parent / "scripts" / "windows" / tool["file"]
        self.log(f"Running {tool['name']}")
        try:
            proc = subprocess.run(
                ["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", str(script_path)],
                capture_output=True,
                text=True,
            )
        except Exception as exc:
            self.log(str(exc), "ERROR")
            self.root.after(0, lambda: messagebox.showerror("HoundFix", str(exc)))
            return
        out = (proc.stdout or "") + (proc.stderr or "")
        if proc.returncode == 0:
            self.log(f"OK {tool['name']}")
            if out.strip():
                self.log(out.strip()[:800])
            self.root.after(0, lambda: messagebox.showinfo("HoundFix", f"{tool['name']} finished."))
        else:
            self.log(out.strip() or f"exit {proc.returncode}", "ERROR")
            self.root.after(0, lambda: messagebox.showerror("HoundFix", out[:400] or "Failed"))


def main():
    root = tk.Tk()
    HoundFix(root)
    root.mainloop()


if __name__ == "__main__":
    main()
