$out = Join-Path $env:USERPROFILE 'Desktop\\houndfix-battery-report.html'
powercfg /batteryreport /output $out
Write-Output "Wrote $out"
