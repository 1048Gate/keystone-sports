Get-PnpDevice | Where-Object { $_.Status -ne 'OK' } |
  Format-Table Status, Class, FriendlyName, InstanceId -AutoSize
Write-Output "Driver check complete."
