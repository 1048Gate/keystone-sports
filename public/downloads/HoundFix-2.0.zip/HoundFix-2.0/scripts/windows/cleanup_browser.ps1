$paths = @(
  "$env:LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Cache",
  "$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\Default\\Cache",
  "$env:APPDATA\\Mozilla\\Firefox\\Profiles"
)
Get-ChildItem "$env:APPDATA\\Mozilla\\Firefox\\Profiles" -ErrorAction SilentlyContinue |
  ForEach-Object { Join-Path $_.FullName 'cache2' } |
  ForEach-Object { $paths += $_ }
foreach ($p in $paths) {
  if (Test-Path $p) {
    Remove-Item -Path (Join-Path $p '*') -Recurse -Force -ErrorAction SilentlyContinue
    Write-Output "Cleared $p"
  }
}
Write-Output "Browser cleanup complete."
