Stop-Service wuauserv, bits -Force -ErrorAction SilentlyContinue
Remove-Item "$env:SystemRoot\\SoftwareDistribution\\Download\\*" -Recurse -Force -ErrorAction SilentlyContinue
Start-Service bits, wuauserv
Write-Output "Update cache cleared."
