$mp = "$env:ProgramFiles\\Windows Defender\\MpCmdRun.exe"
if (Test-Path $mp) {
  & $mp -Scan -ScanType 1
} else {
  Start-MpScan -ScanType QuickScan
}
Write-Output "Defender quick scan finished."
