bcdedit /deletevalue '{current}' safeboot
Write-Output "Safe Mode flag cleared."
