bcdedit /set '{current}' safeboot minimal
Write-Output "Safe Mode armed for next reboot. Use Disable Safe Mode after."
