Get-WinEvent -FilterHashtable @{ LogName='System'; Level=2; StartTime=(Get-Date).AddHours(-24) } -MaxEvents 20 -ErrorAction SilentlyContinue |
  Format-Table TimeCreated, ProviderName, Id, Message -Wrap -AutoSize
