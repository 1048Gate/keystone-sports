netsh advfirewall reset
Write-Output "Firewall reset to defaults."
