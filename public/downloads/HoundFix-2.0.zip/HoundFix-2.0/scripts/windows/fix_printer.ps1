Stop-Service -Name Spooler -Force -ErrorAction SilentlyContinue
$spool = Join-Path $env:SystemRoot 'System32\\spool\\PRINTERS\\*'
Remove-Item -Path $spool -Force -Recurse -ErrorAction SilentlyContinue
Start-Service -Name Spooler
Get-Service Spooler | Format-List Name, Status
Write-Output "Print spooler restarted."
