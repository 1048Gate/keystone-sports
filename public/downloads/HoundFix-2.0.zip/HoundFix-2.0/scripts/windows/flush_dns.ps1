ipconfig /flushdns
Write-Output "DNS cache flushed."
