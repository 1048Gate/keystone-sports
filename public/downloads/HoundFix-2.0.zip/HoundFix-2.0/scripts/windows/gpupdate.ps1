gpupdate /force
Write-Output "Group policy refresh requested."
