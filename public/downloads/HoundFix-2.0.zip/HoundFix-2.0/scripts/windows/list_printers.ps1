Get-Printer | Format-Table Name, DriverName, PortName, PrinterStatus -AutoSize
Write-Output "Default: $((Get-CimInstance Win32_Printer | Where-Object { $_.Default }).Name)"
