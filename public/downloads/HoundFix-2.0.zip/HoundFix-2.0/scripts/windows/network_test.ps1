Resolve-DnsName google.com -ErrorAction SilentlyContinue | Format-Table -AutoSize
ping -n 4 8.8.8.8
Get-NetAdapter | Format-Table Name, Status, LinkSpeed, MacAddress -AutoSize
ipconfig /all
