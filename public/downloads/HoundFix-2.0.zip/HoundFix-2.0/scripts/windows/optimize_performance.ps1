Remove-Item "$env:TEMP\\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "Temp trimmed. For power plans use: powercfg /list"
powercfg /getactivescheme
