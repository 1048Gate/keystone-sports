ipconfig /flushdns
ipconfig /release
ipconfig /renew
netsh winsock reset
netsh int ip reset
Write-Output "Network stack reset. Reboot recommended."
