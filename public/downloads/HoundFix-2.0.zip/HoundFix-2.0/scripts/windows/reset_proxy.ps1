netsh winhttp reset proxy
reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f | Out-Null
Write-Output "Proxy reset."
