Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | ForEach-Object {
  Write-Output "Restarting $($_.Name)"
  Disable-NetAdapter -Name $_.Name -Confirm:$false
  Start-Sleep -Seconds 2
  Enable-NetAdapter -Name $_.Name -Confirm:$false
}
Write-Output "Adapters restarted."
