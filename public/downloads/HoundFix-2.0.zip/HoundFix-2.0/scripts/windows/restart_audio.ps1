Restart-Service Audiosrv, AudioEndpointBuilder -Force
Write-Output "Audio services restarted."
