Stop-Process -Name explorer -Force
Start-Process explorer
Write-Output "Explorer restarted."
