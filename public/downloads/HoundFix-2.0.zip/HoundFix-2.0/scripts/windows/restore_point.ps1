Checkpoint-Computer -Description "HoundFix" -RestorePointType MODIFY_SETTINGS
Write-Output "Restore point created."
