Stop-Service WSearch -Force -ErrorAction SilentlyContinue
Remove-Item "$env:ProgramData\\Microsoft\\Search\\Data\\Applications\\Windows\\*" -Recurse -Force -ErrorAction SilentlyContinue
Start-Service WSearch
Write-Output "Search indexer reset. Indexing will rebuild in the background."
