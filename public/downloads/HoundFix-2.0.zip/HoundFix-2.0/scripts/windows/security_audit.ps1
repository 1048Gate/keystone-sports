Get-NetFirewallProfile | Format-Table Name, Enabled
Get-MpComputerStatus | Select-Object AMServiceEnabled, AntivirusEnabled, RealTimeProtectionEnabled, IoavProtectionEnabled
Get-BitLockerVolume -ErrorAction SilentlyContinue | Format-Table MountPoint, ProtectionStatus, VolumeStatus
Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
Write-Output "Security snapshot complete."
