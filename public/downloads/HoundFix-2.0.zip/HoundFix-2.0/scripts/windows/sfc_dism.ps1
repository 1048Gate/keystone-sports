Write-Output "DISM RestoreHealth..."
DISM /Online /Cleanup-Image /RestoreHealth
Write-Output "SFC scan..."
sfc /scannow
Write-Output "Repair pass finished."
