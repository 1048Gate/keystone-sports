netsh wlan show profiles
$current = (netsh wlan show interfaces) | Select-String 'SSID' | Select-Object -First 1
Write-Output $current
netsh wlan show profile name=* key=clear | Select-String 'Profile','Key Content','SSID name'
