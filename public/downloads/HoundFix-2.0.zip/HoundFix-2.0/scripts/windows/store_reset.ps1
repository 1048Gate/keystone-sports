Start-Process wsreset.exe -Wait
Get-AppxPackage Microsoft.WindowsStore | ForEach-Object {
  Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\\AppXManifest.xml"
}
Write-Output "Store reset complete."
