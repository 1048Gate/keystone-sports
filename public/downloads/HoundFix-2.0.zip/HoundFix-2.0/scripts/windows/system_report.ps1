Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, OsBuildNumber, CsName, CsProcessors, CsTotalPhysicalMemory
Get-CimInstance Win32_LogicalDisk | Select-Object DeviceID, @{N='GBFree';E={[math]::Round($_.FreeSpace/1GB,1)}}, @{N='GBSize';E={[math]::Round($_.Size/1GB,1)}}
Get-Process | Measure-Object WorkingSet -Sum | ForEach-Object { "Process RAM MB: $([math]::Round($_.Sum/1MB,0))" }
