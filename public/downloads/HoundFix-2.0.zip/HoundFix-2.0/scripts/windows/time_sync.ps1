w32tm /resync /force
w32tm /query /status
Write-Output "Time sync requested."
