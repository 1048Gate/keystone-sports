$session = New-Object -ComObject Microsoft.Update.Session
$searcher = $session.CreateUpdateSearcher()
$res = $searcher.Search("IsInstalled=0")
Write-Output "Found $($res.Updates.Count) available updates"
$res.Updates | Select-Object -First 20 Title | Format-Table -AutoSize
